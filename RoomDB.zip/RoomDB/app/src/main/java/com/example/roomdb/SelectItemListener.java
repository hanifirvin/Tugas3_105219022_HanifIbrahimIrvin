package com.example.roomdb;

public interface SelectItemListener {
    void onItemClick(Word word);
}
